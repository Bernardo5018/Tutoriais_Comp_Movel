package tasks

import contributors.*
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext

suspend fun loadContributorsNotCancellable(service: GitHubService, req: RequestData): List<User> =
    withContext(NonCancellable) {
        loadContributorsConcurrent(service, req)
    }
