package tasks

import contributors.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

suspend fun loadContributorsChannels(
    service: GitHubService,
    req: RequestData,
    updateResults: suspend (List<User>, completed: Boolean) -> Unit
) {
    coroutineScope {
        val repos = service
            .getOrgRepos(req.org)
            .also { logRepos(req, it) }
            .bodyList()

        val usersChannel = Channel<List<User>>(Channel.BUFFERED)

        repos.forEach { repo ->
            launch {
                val users = service
                    .getRepoContributors(req.org, repo.name)
                    .also { logUsers(repo, it) }
                    .bodyList()
                usersChannel.send(users)
            }
        }

        val allUsers = mutableListOf<User>()
        repeat(repos.size) { index ->
            val users = usersChannel.receive()
            allUsers += users
            updateResults(allUsers.aggregate(), index == repos.lastIndex)
        }

        usersChannel.close()
    }
}
