Gemini Image Processing - Tutorial 4, Task 5

Objetivo:
Aplicação Android em Kotlin para enviar uma imagem + prompt para a API Gemini.
A app tem 3 imagens locais: bolo de chocolate, bolo de morango e cookies.

Funcionalidades:
- Escolha de uma das 3 imagens.
- Caixa para Gemini API Key.
- Caixa para prompt.
- Prompts rápidos: receita, nome criativo, ingredientes e calorias.
- Envio de imagem + texto para Gemini 2.0 Flash via REST API.
- Mostra resposta na app.
- Extra: botão copiar resposta.
- Extra: botão limpar resposta.
- Extra: histórico local dos últimos prompts.

Como configurar:
Opção A - pela app:
1. Abrir a app.
2. Colar a Gemini API Key no campo "Gemini API Key".
3. Escolher imagem e enviar prompt.

Opção B - por ficheiro local.properties:
1. Criar/editar o ficheiro local.properties na raiz do projeto.
2. Adicionar a linha:
   GEMINI_API_KEY=A_TUA_KEY_AQUI
3. Fazer Sync Project with Gradle Files.
4. Correr a app.

Nota:
Se aparecer erro HTTP 429, o problema é quota da API Gemini, não é erro da app.
