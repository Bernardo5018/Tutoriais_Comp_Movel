# No special rules needed for this simple tutorial app.
