package cm.a15033.geminiimageprocessing

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    private data class FoodImage(val title: String, val resId: Int)

    private val images = listOf(
        FoodImage("Bolo chocolate", R.drawable.cake_chocolate),
        FoodImage("Bolo morango", R.drawable.cake_strawberry),
        FoodImage("Cookies", R.drawable.cookies)
    )

    private lateinit var keyEdit: EditText
    private lateinit var promptEdit: EditText
    private lateinit var responseText: TextView
    private lateinit var statusText: TextView
    private lateinit var historyText: TextView
    private lateinit var imageViews: List<ImageView>

    private var selectedImageIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createLayout()
    }

    private fun createLayout() {
        val prefs = getSharedPreferences("gemini_image_prefs", MODE_PRIVATE)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(34, 199, 232))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(18), dp(18), dp(28))
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Gemini Image Processing"
        title.textSize = 25f
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        root.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "Escolhe uma imagem, escreve um prompt e envia para o Gemini."
        subtitle.textSize = 14f
        subtitle.setTextColor(Color.WHITE)
        subtitle.setPadding(0, dp(6), 0, dp(12))
        root.addView(subtitle)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.background = rounded(Color.WHITE, dp(14), Color.TRANSPARENT, 0)
        root.addView(card, LinearLayout.LayoutParams(-1, -2))

        keyEdit = EditText(this)
        keyEdit.hint = "Gemini API Key"
        keyEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val savedKey = BuildConfig.GEMINI_API_KEY.ifBlank { prefs.getString("apiKey", "") ?: "" }
        keyEdit.setText(savedKey)
        card.addView(keyEdit)

        val promptModes = arrayOf(
            "Receita para esta imagem",
            "Nome criativo",
            "Ingredientes prováveis",
            "Calorias aproximadas",
            "Prompt personalizado"
        )

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, promptModes)
        card.addView(spinner)

        promptEdit = EditText(this)
        promptEdit.hint = "Escreve o teu prompt"
        promptEdit.minLines = 3
        promptEdit.gravity = Gravity.TOP
        promptEdit.setText("Give me a simple recipe for this cake or cookie.")
        card.addView(promptEdit)

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val prompt = when (position) {
                    0 -> "Give me a simple recipe for this cake or cookie."
                    1 -> "Suggest a creative name for this cake or cookie."
                    2 -> "List the most likely ingredients in this image."
                    3 -> "Estimate the approximate calories and explain your reasoning briefly."
                    else -> promptEdit.text.toString()
                }
                if (position != 4) promptEdit.setText(prompt)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        val imageTitle = TextView(this)
        imageTitle.text = "Imagens"
        imageTitle.textSize = 18f
        imageTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        imageTitle.setPadding(0, dp(14), 0, dp(8))
        card.addView(imageTitle)

        val imagesRow = LinearLayout(this)
        imagesRow.orientation = LinearLayout.HORIZONTAL
        card.addView(imagesRow)

        val tempImageViews = mutableListOf<ImageView>()
        images.forEachIndexed { index, foodImage ->
            val container = LinearLayout(this)
            container.orientation = LinearLayout.VERTICAL
            container.gravity = Gravity.CENTER
            container.setPadding(dp(5), dp(5), dp(5), dp(5))
            imagesRow.addView(container, LinearLayout.LayoutParams(0, -2, 1f))

            val imageView = ImageView(this)
            imageView.setImageResource(foodImage.resId)
            imageView.scaleType = ImageView.ScaleType.CENTER_CROP
            imageView.setPadding(dp(4), dp(4), dp(4), dp(4))
            imageView.setOnClickListener {
                selectedImageIndex = index
                updateImageSelection()
            }
            container.addView(imageView, LinearLayout.LayoutParams(-1, dp(105)))

            val label = TextView(this)
            label.text = foodImage.title
            label.gravity = Gravity.CENTER
            label.textSize = 12f
            container.addView(label)

            tempImageViews.add(imageView)
        }
        imageViews = tempImageViews
        updateImageSelection()

        val sendButton = Button(this)
        sendButton.text = "Enviar para Gemini"
        sendButton.setOnClickListener { sendToGemini() }
        card.addView(sendButton)

        val buttonsRow = LinearLayout(this)
        buttonsRow.orientation = LinearLayout.HORIZONTAL
        card.addView(buttonsRow)

        val copyButton = Button(this)
        copyButton.text = "Copiar resposta"
        copyButton.setOnClickListener { copyResponse() }
        buttonsRow.addView(copyButton, LinearLayout.LayoutParams(0, -2, 1f))

        val clearButton = Button(this)
        clearButton.text = "Limpar"
        clearButton.setOnClickListener {
            responseText.text = ""
            statusText.text = "Pronto."
        }
        buttonsRow.addView(clearButton, LinearLayout.LayoutParams(0, -2, 1f))

        statusText = TextView(this)
        statusText.text = "Pronto."
        statusText.setTextColor(Color.DKGRAY)
        statusText.setPadding(0, dp(8), 0, dp(8))
        card.addView(statusText)

        responseText = TextView(this)
        responseText.textSize = 15f
        responseText.setTextColor(Color.rgb(30, 41, 59))
        responseText.setPadding(dp(12), dp(12), dp(12), dp(12))
        responseText.background = rounded(Color.rgb(245, 247, 250), dp(10), Color.rgb(230, 230, 230), 1)
        responseText.text = "A resposta do Gemini aparece aqui."
        card.addView(responseText, LinearLayout.LayoutParams(-1, -2))

        historyText = TextView(this)
        historyText.textSize = 13f
        historyText.setTextColor(Color.DKGRAY)
        historyText.setPadding(0, dp(12), 0, 0)
        card.addView(historyText)
        updateHistoryText()

        setContentView(scroll)
    }

    private fun sendToGemini() {
        val apiKey = keyEdit.text.toString().trim()
        val prompt = promptEdit.text.toString().trim()

        if (apiKey.isEmpty()) {
            Toast.makeText(this, "Mete a tua Gemini API Key.", Toast.LENGTH_SHORT).show()
            return
        }
        if (prompt.isEmpty()) {
            Toast.makeText(this, "Escreve um prompt.", Toast.LENGTH_SHORT).show()
            return
        }

        getSharedPreferences("gemini_image_prefs", MODE_PRIVATE)
            .edit()
            .putString("apiKey", apiKey)
            .apply()

        statusText.text = "A enviar pedido ao Gemini..."
        responseText.text = "Aguarda..."

        Thread {
            try {
                val result = callGemini(apiKey, prompt, images[selectedImageIndex].resId)
                runOnUiThread {
                    responseText.text = result
                    statusText.text = "Resposta recebida."
                    saveHistory(prompt)
                    updateHistoryText()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    responseText.text = e.message ?: "Erro desconhecido."
                    statusText.text = "Erro ao chamar o Gemini."
                }
            }
        }.start()
    }

    private fun callGemini(apiKey: String, prompt: String, imageResId: Int): String {
        val imageBase64 = imageToBase64(imageResId)
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey")

        val textPart = JSONObject().put("text", prompt)
        val imagePart = JSONObject().put(
            "inline_data",
            JSONObject()
                .put("mime_type", "image/png")
                .put("data", imageBase64)
        )

        val contents = JSONArray().put(
            JSONObject().put(
                "parts",
                JSONArray().put(textPart).put(imagePart)
            )
        )

        val generationConfig = JSONObject()
            .put("temperature", 0.7)
            .put("maxOutputTokens", 800)

        val body = JSONObject()
            .put("contents", contents)
            .put("generationConfig", generationConfig)
            .toString()

        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.setRequestProperty("Content-Type", "application/json")
        connection.doOutput = true
        connection.connectTimeout = 20000
        connection.readTimeout = 45000

        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        connection.disconnect()

        if (code !in 200..299) {
            return "Erro HTTP $code\n\n$response\n\nSe aparecer 429, a tua API key está sem quota."
        }

        val json = JSONObject(response)
        val candidates = json.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            return "O Gemini não devolveu candidatos.\n\n$response"
        }

        val content = candidates
            .getJSONObject(0)
            .getJSONObject("content")
        val parts = content.getJSONArray("parts")
        val firstPart = parts.getJSONObject(0)
        return firstPart.optString("text", "Sem texto na resposta.")
    }

    private fun imageToBase64(imageResId: Int): String {
        val bitmap = BitmapFactory.decodeResource(resources, imageResId)
        val output = ByteArrayOutputStream()
        bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, output)
        return Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
    }

    private fun updateImageSelection() {
        imageViews.forEachIndexed { index, imageView ->
            if (index == selectedImageIndex) {
                imageView.background = rounded(Color.WHITE, dp(8), Color.rgb(34, 199, 232), 5)
            } else {
                imageView.background = rounded(Color.WHITE, dp(8), Color.LTGRAY, 1)
            }
        }
    }

    private fun copyResponse() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Gemini response", responseText.text.toString()))
        Toast.makeText(this, "Resposta copiada.", Toast.LENGTH_SHORT).show()
    }

    private fun saveHistory(prompt: String) {
        val prefs = getSharedPreferences("gemini_image_prefs", MODE_PRIVATE)
        val old = prefs.getStringSet("history", emptySet())?.toMutableList() ?: mutableListOf()
        old.remove(prompt)
        old.add(0, prompt)
        val limited = old.take(5).toSet()
        prefs.edit().putStringSet("history", limited).apply()
    }

    private fun updateHistoryText() {
        val prefs = getSharedPreferences("gemini_image_prefs", MODE_PRIVATE)
        val history = prefs.getStringSet("history", emptySet())?.toList().orEmpty()
        historyText.text = if (history.isEmpty()) {
            "Extra: prompts rápidos, copiar resposta, limpar resposta e histórico local."
        } else {
            "Histórico local:\n" + history.joinToString("\n") { "• $it" }
        }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int, strokeWidth: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
