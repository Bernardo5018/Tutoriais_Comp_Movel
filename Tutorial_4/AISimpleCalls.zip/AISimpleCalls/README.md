# LLM Assistant Application

This application provides a simple command-line interface to interact with AI language models, supporting both OpenAI and Google Gemini models.

## Features

- Support for both OpenAI and Google Gemini AI models
- Extensible design with AIAssistant interface for easy addition of new AI providers
- Factory pattern for creating the appropriate assistant based on configuration
- Configurable model selection with efficient properties caching
- Robust error handling with retry mechanism
- Structured logging with configurable log levels

## Setup

1. Clone the repository
2. Create a `config.properties` file in one of these locations:
   - In the project root directory (recommended for development)
   - In the `src/main/resources` directory (for packaged applications)
   - In your user's working directory
3. Configure your API keys in the `config.properties` file:
   - For OpenAI: Get an API key from [OpenAI Platform](https://platform.openai.com/)
   - For Gemini: Get an API key from [Google AI Studio](https://ai.google.dev/)
4. Build the project using Gradle:
   ```
   ./gradlew build
   ```
5. Run the application:
   ```
   ./gradlew run
   ```

## Configuration

The `config.properties` file may contain the following settings:

- `OPENAI_API_KEY=...`
- `GEMINI_API_KEY=...`
- `AI_LLM=...` <span style="color: gray;">// Possible values: OPENAI, GEMINI; defaults to OPENAI</span>
- `LOG_LEVEL=...` <span style="color: gray;">// Possible values: OFF, ERROR, WARN, INFO, DEBUG, TRACE; defaults to OFF</span>
## Tutorial 4 changes implemented

This version includes the Tutorial 4 changes for the AI LLM part:

- `TEMPERATURE` can now be configured in `config.properties`.
- `MAX_TOKENS` can now be configured in `config.properties`.
- `PROCESSING_MODE=SIMPLE` keeps the normal assistant behaviour.
- `PROCESSING_MODE=SENTIMENT` forces sentiment analysis.
- The command `/sentiment your text` can be used in the console to force sentiment analysis even when `PROCESSING_MODE=SIMPLE`.
- The sentiment answer is requested in JSON format with:
  - `rating`, from 1 to 7
  - `justification`
- The response parser now accepts both Gemini responses (`candidates`) and OpenAI responses (`choices`).

Check `temperature_tests.txt` for two temperature test cases and one sentiment analysis test.
