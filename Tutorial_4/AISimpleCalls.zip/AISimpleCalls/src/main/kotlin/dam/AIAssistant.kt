package dam

import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONException
import org.json.JSONObject
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import java.util.Properties
import kotlin.math.pow

enum class ProcessingMode { SIMPLE, SENTIMENT }

/**
 * AIAssistant interface defines the contract for different AI assistant implementations.
 */
interface AIAssistant {

    val properties: Properties

    val logger: Logger
        get() = LoggerFactory.getLogger(this::class.java)

    val apiKeyName: String
    var model: String

    val client: OkHttpClient
        get() = OkHttpClient()

    val apiKey: String
        get() = properties.getProperty(apiKeyName)
            ?: throw IllegalStateException("API key $apiKeyName not found in configuration file.")

    val temperature: Double?
        get() = properties.getProperty("TEMPERATURE")?.toDoubleOrNull()

    val maxTokens: Int?
        get() = properties.getProperty("MAX_TOKENS")?.toIntOrNull()

    fun getSystem(): String

    fun getProcessingMode(): ProcessingMode {
        return when (properties.getProperty("PROCESSING_MODE", "SIMPLE").uppercase()) {
            "SENTIMENT" -> ProcessingMode.SENTIMENT
            else -> ProcessingMode.SIMPLE
        }
    }

    suspend fun processInput(input: String): String {
        val formattedPrompt = when (getProcessingMode()) {
            ProcessingMode.SIMPLE -> buildPrompt(input)
            ProcessingMode.SENTIMENT -> buildSentimentPrompt(input)
        }
        return apiCallWithBackoff(formattedPrompt)
    }

    suspend fun processSentiment(input: String): String {
        return apiCallWithBackoff(buildSentimentPrompt(input))
    }

    fun buildPrompt(input: String): String {
        return """
            Your name is Assistant.
            The preferred language is English.
            Respond in a friendly and helpful manner.
            The user's request is: "$input"
            """.trimIndent()
    }

    fun buildSentimentPrompt(input: String): String {
        return """
            Analyse the sentiment of the following text.
            Use this 7-point scale:
            1 = Very Negative
            2 = Negative
            3 = Slightly Negative
            4 = Neutral
            5 = Slightly Positive
            6 = Positive
            7 = Very Positive

            Return only valid JSON in this format:
            {
              "rating": value,
              "justification": value
            }

            Text: "$input"
            """.trimIndent()
    }

    suspend fun apiCallWithBackoff(input: String): String {
        var attempts = 0
        val maxAttempts = 5
        val baseDelay = 1000L

        while (attempts < maxAttempts) {
            try {
                return makeApiCall(input)
            } catch (e: Exception) {
                logger.error("Error message: ${e.message}")
                if (e.message?.contains("429") == true) {
                    attempts++
                    val delayTime = baseDelay * (2.0.pow(attempts.toDouble())).toLong()
                    delay(delayTime)
                } else {
                    throw e
                }
            }
        }
        throw Exception("Exceeded maximum retry attempts")
    }

    fun makeApiCall(prompt: String): String {
        logger.info("Prompt:\n$prompt")
        val request = buildRequest(prompt)

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string()
                throw Exception("Error in API call: ${response.code} - ${response.message}\nResponse: $errorBody")
            }

            val responseBody = response.body?.string() ?: return "Error: empty response"

            try {
                val json = JSONObject(responseBody)
                logger.debug("Raw API response: {}", responseBody)
                return extractTextFromResponse(json)
            } catch (e: JSONException) {
                val truncatedResponse = if (responseBody.length > 200)
                    "${responseBody.substring(0, 200)}..."
                else
                    responseBody
                logger.error("Error parsing JSON response: ${e.message}")
                logger.error("Response body (truncated): $truncatedResponse")
                throw Exception("Failed to parse API response: ${e.message}", e)
            }
        }
    }

    fun extractTextFromResponse(json: JSONObject): String {
        // Gemini response: candidates[0].content.parts[0].text
        if (json.has("candidates")) {
            val candidates = json.getJSONArray("candidates")
            if (candidates.length() == 0) return "Error: No candidates found in the API response"

            val firstCandidate = candidates.getJSONObject(0)
            if (!firstCandidate.has("content")) return "Error: No content found in the API response"

            val content = firstCandidate.getJSONObject("content")
            if (!content.has("parts")) return "Error: No parts found in the API response"

            val parts = content.getJSONArray("parts")
            if (parts.length() == 0) return "Error: No parts found in the API response"

            val firstPart = parts.getJSONObject(0)
            if (!firstPart.has("text")) return "Error: No text found in the API response"

            return firstPart.getString("text").trim()
        }

        // OpenAI response: choices[0].message.content
        if (json.has("choices")) {
            val choices = json.getJSONArray("choices")
            if (choices.length() == 0) return "Error: No choices found in the API response"

            val firstChoice = choices.getJSONObject(0)
            if (!firstChoice.has("message")) return "Error: No message found in the API response"

            val message = firstChoice.getJSONObject("message")
            if (!message.has("content")) return "Error: No content found in the API response"

            return message.getString("content").trim()
        }

        return "Error: Unknown API response format"
    }

    fun buildRequest(prompt: String): Request
}
