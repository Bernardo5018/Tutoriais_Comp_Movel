package dam

import kotlinx.coroutines.runBlocking

/**
 * Main entry point for the LLM Assistant application
 */
fun main() = runBlocking {
    println("\nStarting LLM Assistant application...\n")

    val properties = getProperties()
    configureLogging(properties)
    println()

    println("Using AI_LLM: ${properties.getProperty("AI_LLM")}")
    println("PROCESSING_MODE: ${properties.getProperty("PROCESSING_MODE", "SIMPLE")}")
    println("TEMPERATURE: ${properties.getProperty("TEMPERATURE", "undefined")}")
    println("MAX_TOKENS: ${properties.getProperty("MAX_TOKENS", "undefined")}")

    val assistant: AIAssistant = AIAssistantFactory.createAssistant(properties)
    println("Using: ${assistant.getSystem()} ${assistant.model}\n")

    println("Type your questions and press Enter.")
    println("Use /sentiment your text to force sentiment analysis.")
    println("Press Ctrl+D (Unix/Mac) or Ctrl+Z (Windows) to exit.\n")

    while (true) {
        println("--------------------")
        print("Your question: ")
        val input = readlnOrNull() ?: break

        if (input.isBlank()) {
            println("Please enter a question or press Ctrl+D to exit.")
            continue
        }

        val output = if (input.startsWith("/sentiment ")) {
            assistant.processSentiment(input.removePrefix("/sentiment "))
        } else {
            assistant.processInput(input)
        }
        println("\nAnswer: $output\n")
    }

    println("\nThank you for using LLM Assistant. Goodbye!")
}
