plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
rootProject.name = "GreetingProcessor"
include("annotations")
include("app")
include("processor")