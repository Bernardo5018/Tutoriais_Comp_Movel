package processor

import annotations.Extract
import com.google.auto.service.AutoService
import com.squareup.kotlinpoet.*
import java.io.File
import javax.annotation.processing.*
import javax.lang.model.SourceVersion
import javax.lang.model.element.ExecutableElement
import javax.lang.model.element.TypeElement
import javax.tools.Diagnostic

@AutoService(Processor::class)
@SupportedSourceVersion(SourceVersion.RELEASE_17)
@SupportedAnnotationTypes("annotations.Extract")
class RegexProcessor : AbstractProcessor() {

    override fun process(
        annotations: MutableSet<out TypeElement>,
        roundEnv: RoundEnvironment
    ): Boolean {

        for (element in roundEnv.getElementsAnnotatedWith(Extract::class.java)) {
            if (element is ExecutableElement) {
                val classElement = element.enclosingElement as TypeElement
                generateExtractorClass(classElement)
                break
            }
        }

        return true
    }

    @OptIn(DelicateKotlinPoetApi::class)
    private fun generateExtractorClass(classElement: TypeElement) {
        val packageName =
            processingEnv.elementUtils.getPackageOf(classElement).toString()

        val originalClassName = classElement.simpleName.toString()
        val extractorClassName = "${originalClassName}Extractor"

        val inputType = String::class.asClassName()

        val classBuilder = TypeSpec.classBuilder(extractorClassName)
            .primaryConstructor(
                FunSpec.constructorBuilder()
                    .addParameter("input", inputType)
                    .build()
            )
            .superclass(ClassName(packageName, originalClassName))
            .addSuperclassConstructorParameter("input")
            .addModifiers(KModifier.PUBLIC)

        val methods = classElement.enclosedElements.filterIsInstance<ExecutableElement>()

        for (method in methods) {
            val extract = method.getAnnotation(Extract::class.java)

            if (extract != null) {
                val methodName = method.simpleName.toString()
                val regex = extract.regex

                val methodBuilder = FunSpec.builder(methodName)
                    .addModifiers(KModifier.OVERRIDE)
                    .returns(String::class.asClassName().copy(nullable = true))
                    .addStatement("val match = Regex(%S).find(input)", regex)
                    .addStatement("return match?.groupValues?.get(1)")

                classBuilder.addFunction(methodBuilder.build())
            }
        }

        val file = FileSpec.builder(packageName, extractorClassName)
            .addImport("kotlin.text", "Regex")
            .addType(classBuilder.build())
            .build()

        try {
            val kaptKotlinGeneratedDir =
                processingEnv.options["kapt.kotlin.generated"]

            if (kaptKotlinGeneratedDir != null) {
                file.writeTo(File(kaptKotlinGeneratedDir))
            } else {
                processingEnv.messager.printMessage(
                    Diagnostic.Kind.ERROR,
                    "kapt.kotlin.generated not found"
                )
            }
        } catch (e: Exception) {
            processingEnv.messager.printMessage(
                Diagnostic.Kind.ERROR,
                "Error generating Regex file: ${e.message}"
            )
        }
    }
}