package org.example.cm.exe_2

// Exercise 1.2 - Generics: A Type-Safe In-Memory Cache

class Cache<K : Any, V : Any> {

    private val store: MutableMap<K, V> = HashMap()

    fun put(key: K, value: V) {
        store[key] = value
    }

    fun get(key: K): V? {
        return store[key]
    }

    fun evict(key: K) {
        store.remove(key)
    }

    fun size(): Int {
        return store.size
    }

    fun getOrPut(key: K, default: () -> V): V {
        if (store.containsKey(key)) {
            return store[key]!!
        }
        val value = default()
        store[key] = value
        return value
    }

    fun transform(key: K, action: (V) -> V): Boolean {
        if (!store.containsKey(key)) {
            return false
        }
        store[key] = action(store[key]!!)
        return true
    }

    fun snapshot(): Map<K, V> {
        return HashMap(store)
    }

    // Challenge [2%]
    fun filterValues(predicate: (V) -> Boolean): Map<K, V> {
        val result = HashMap<K, V>()
        for ((key, value) in store) {
            if (predicate(value)) {
                result[key] = value
            }
        }
        return result
    }
}

fun main() {
    println("--- Word frequency cache ---")
    val wordCache = Cache<String, Int>()
    wordCache.put("kotlin", 1)
    wordCache.put("scala", 1)
    wordCache.put("haskell", 1)

    println("Size: ${wordCache.size()}")
    println("Frequency of \"kotlin\": ${wordCache.get("kotlin")}")
    println("getOrPut \"kotlin\": ${wordCache.getOrPut("kotlin") { 0 }}")
    println("getOrPut \"java\": ${wordCache.getOrPut("java") { 0 }}")
    println("Size after getOrPut: ${wordCache.size()}")
    println("Transform \"kotlin\" (+1): ${wordCache.transform("kotlin") { it + 1 }}")
    println("Transform \"cobol\" (+1): ${wordCache.transform("cobol") { it + 1 }}")
    println("Snapshot: ${wordCache.snapshot()}")

    // Challenge
    val nonZero = wordCache.filterValues { it > 0 }
    println("Words with count > 0: $nonZero")

    println()
    println("--- Id registry cache ---")
    val idCache = Cache<Int, String>()
    idCache.put(1, "Alice")
    idCache.put(2, "Bob")
    println("Id 1 -> ${idCache.get(1)}")
    println("Id 2 -> ${idCache.get(2)}")
    idCache.evict(1)
    println("After evict id 1, size: ${idCache.size()}")
    println("Id 1 after evict -> ${idCache.get(1)}")
}