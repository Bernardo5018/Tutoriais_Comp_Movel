package org.example.cm.exe_4

// Exercise 1.4 - Operator Overloading: A 2D Vector Library

import kotlin.math.sqrt

data class Vec2(val x: Double, val y: Double) : Comparable<Vec2> {

    operator fun plus(other: Vec2): Vec2 {
        return Vec2(x + other.x, y + other.y)
    }

    operator fun minus(other: Vec2): Vec2 {
        return Vec2(x - other.x, y - other.y)
    }

    operator fun times(scalar: Double): Vec2 {
        return Vec2(x * scalar, y * scalar)
    }

    operator fun unaryMinus(): Vec2 {
        return Vec2(-x, -y)
    }

    override fun compareTo(other: Vec2): Int {
        return this.magnitude().compareTo(other.magnitude())
    }

    fun magnitude(): Double {
        return sqrt(x * x + y * y)
    }

    fun dot(other: Vec2): Double {
        return x * other.x + y * other.y
    }

    fun normalized(): Vec2 {
        val mag = magnitude()
        if (mag == 0.0) {
            throw IllegalStateException("Cannot normalize the zero vector")
        }
        return Vec2(x / mag, y / mag)
    }

    operator fun get(index: Int): Double {
        if (index == 0) return x
        if (index == 1) return y
        throw IndexOutOfBoundsException("Index $index out of bounds for Vec2")
    }
}

// Challenge - left-hand scalar: 2.0 * v
operator fun Double.times(v: Vec2): Vec2 {
    return Vec2(this * v.x, this * v.y)
}

fun main() {
    val a = Vec2(3.0, 4.0)
    val b = Vec2(1.0, 2.0)

    println("a = $a")
    println("b = $b")
    println("a + b = ${a + b}")
    println("a - b = ${a - b}")
    println("a * 2.0 = ${a * 2.0}")
    println("-a = ${-a}")
    println("|a| = ${a.magnitude()}")
    println("a dot b = ${a.dot(b)}")
    println("norm(a) = ${a.normalized()}")
    println("a[0] = ${a[0]}")
    println("a[1] = ${a[1]}")
    println("a > b = ${a > b}")
    println("a < b = ${a < b}")

    val vectors = listOf(Vec2(1.0, 0.0), Vec2(3.0, 4.0), Vec2(0.0, 2.0))
    println("Longest = ${vectors.max()}")
    println("Shortest = ${vectors.min()}")

    println("2.0 * a = ${2.0 * a}")

    val (x, y) = a
    println("Destructuring a: x=$x, y=$y")
}