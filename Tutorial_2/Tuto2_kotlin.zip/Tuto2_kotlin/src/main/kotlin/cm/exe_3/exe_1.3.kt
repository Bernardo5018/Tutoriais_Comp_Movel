package org.example.cm.exe_3

// Exercise 1.3 - Functions and Lambdas: A Configurable Data Pipeline

class Pipeline {

    private val stages: MutableList<Pair<String, (List<String>) -> List<String>>> = mutableListOf()

    fun addStage(name: String, transform: (List<String>) -> List<String>) {
        stages.add(Pair(name, transform))
    }

    fun execute(input: List<String>): List<String> {
        var result = input
        for (stage in stages) {
            result = stage.second(result)
        }
        return result
    }

    fun describe() {
        println("Pipeline stages:")
        for (i in stages.indices) {
            println("${i + 1}. ${stages[i].first}")
        }
    }

    // Challenge [4%]
    fun compose(nameA: String, nameB: String, newName: String) {
        var transformA: ((List<String>) -> List<String>)? = null
        var transformB: ((List<String>) -> List<String>)? = null

        for (stage in stages) {
            if (stage.first == nameA) transformA = stage.second
            if (stage.first == nameB) transformB = stage.second
        }

        if (transformA == null || transformB == null) return

        val a = transformA
        val b = transformB
        addStage(newName) { input -> b(a(input)) }
    }

    fun fork(other: Pipeline, input: List<String>): Pair<List<String>, List<String>> {
        return Pair(this.execute(input), other.execute(input))
    }
}

fun buildPipeline(block: Pipeline.() -> Unit): Pipeline {
    val pipeline = Pipeline()
    pipeline.block()
    return pipeline
}

fun main() {
    val logs = listOf(
        "  INFO: server started",
        "  ERROR: disk full",
        "  DEBUG: checking config",
        "  ERROR: out of memory",
        "  INFO: request received",
        "  ERROR: connection timeout"
    )

    val pipeline = buildPipeline {
        addStage("Trim") { lines ->
            val trimmed = mutableListOf<String>()
            for (line in lines) trimmed.add(line.trim())
            trimmed
        }
        addStage("Filter errors") { lines ->
            val filtered = mutableListOf<String>()
            for (line in lines) if (line.contains("ERROR")) filtered.add(line)
            filtered
        }
        addStage("Uppercase") { lines ->
            val upper = mutableListOf<String>()
            for (line in lines) upper.add(line.uppercase())
            upper
        }
        addStage("Add index") { lines ->
            val indexed = mutableListOf<String>()
            for (i in lines.indices) indexed.add("${i + 1}. ${lines[i]}")
            indexed
        }
    }

    pipeline.describe()
    println()
    println("Result:")
    for (line in pipeline.execute(logs)) {
        println(line)
    }

    // Challenge: fork demo
    println()
    println("--- Fork demo ---")
    val pipelineA = buildPipeline {
        addStage("Trim") { lines ->
            val trimmed = mutableListOf<String>()
            for (line in lines) trimmed.add(line.trim())
            trimmed
        }
        addStage("Filter errors") { lines ->
            val filtered = mutableListOf<String>()
            for (line in lines) if (line.contains("ERROR")) filtered.add(line)
            filtered
        }
    }
    val pipelineB = buildPipeline {
        addStage("Trim") { lines ->
            val trimmed = mutableListOf<String>()
            for (line in lines) trimmed.add(line.trim())
            trimmed
        }
        addStage("Filter info") { lines ->
            val filtered = mutableListOf<String>()
            for (line in lines) if (line.contains("INFO")) filtered.add(line)
            filtered
        }
    }

    val (errors, infos) = pipelineA.fork(pipelineB, logs)
    println("Fork A (errors): $errors")
    println("Fork B (infos):  $infos")
}